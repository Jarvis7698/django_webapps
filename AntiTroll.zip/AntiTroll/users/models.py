from django.db import models
from django.contrib.auth.models import User
from PIL import Image

# Create your models here.

class Profile(models.Model) :

	user = models.OneToOneField(User, on_delete=models.CASCADE)
	mod = models.BooleanField(default=False, verbose_name='Moderator')
	image = models.ImageField(default='default.jpg', upload_to='profile_pics')

	def __str__(self):

		return f'{self.user.username} profile'


	def save(self, **kwargs) :
		
		super().save()

		img = Image.open(self.image.path)

		if img.height > 200 or img.width > 200:
			 output_size = (200, 200)
			 img.thumbnail(output_size)
			 img.save(self.image.path)
