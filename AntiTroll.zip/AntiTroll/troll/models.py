'''
TROLLN'T : Anti-Trolling Support Community Web Application (Django 3.0.3)
Authors: 
        Kunal Acharya (ig:@jarvis.7698, tw:@jarvis7698)
        Sagar Adulkar (ig:@shaggyy11, tw:@SagarAD12)
        Sagar Vyas (ig:@sagarpvyas.97)
Institute:
        Watumull Institute of Electronics Engineering and Computer Technology
'''

from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from PIL import Image

# Create your models here.

class Post(models.Model) :

	hidden = models.BooleanField(default=False)
	title = models.CharField(max_length=150, null=False, blank=False)
	snapshot = models.ImageField(upload_to='snapshots')
	details = models.TextField(default='-')
	op_link = models.TextField(null=True, blank=True, verbose_name="Link to Original Post")
	troll_account_link = models.TextField(null=False, blank=False)
	support = models.ManyToManyField(User, related_name='support', blank=True)
	date = models.DateTimeField(auto_now_add=True)
	author = models.ForeignKey(User, on_delete=models.CASCADE)
	mod_sup = models.IntegerField(default=0)

	def __str__(self):
		return str(self.title)

	def save(self, **kwargs) :
		super().save()

		img = Image.open(self.snapshot.path)

		if img.height > 270 or img.width > 480:
			 output_size = (480, 270)
			 img.thumbnail(output_size)
			 img.save(self.snapshot.path)

	def get_absolute_url(self):
		return reverse('post-detail', kwargs={'pk': self.pk})