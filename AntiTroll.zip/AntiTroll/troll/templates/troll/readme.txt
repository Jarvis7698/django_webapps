
						  ADMIN		(manage users, view supporting users,
						  					verify posts, delete posts, delete users
							|
							V

						MODERATORS  (who can see the supporting users,
											who can verify the post credibility and integrity,
							|					provide support of higher value than users)
							V

						  MEMBERS 	(provide support in mass,
						  					stand for the victim,
						  						report inappropriate behaviour by the troll)
						  	|
						  	V


	ADMIN -> appoints moderators
			 keep a watch on everything via mods

						MODS -> provide transparency among the users
								looking after users and reports

										MEMBERS -> 	actual pillar and highly supportive
													mass report troll accounts on possibly any social media


	Our application provides a platform for troll victims or people who are on a mission to stop trolls.

	this application is social media platform independent as it provides critical care towards inappropriate behaviour observed accross the internet.

	Any member who is either a troll victim or is willing to support another victim with a vision of minimizing these cyber-bullying accounts found accross nearly any social media say YouTube, Twitter, Instagram, Tumblr, Pinterest, and many more...

	A member can report a troll by creating a post with legit proofs of being trolled or witnessing such activity.
	A post requires 
		* a well described title as well as details,
		* a snapshot of the actions by the troll, 
		* a link to the original post where trolling activity was carried out if possible,
		* a direct link to the account indulged into bullying or trolling,

	after a post is created, it is the job of moderators to verify and make sure the report is genuine and found guilty from valid sources.

	Members can take a stand against the troll by looking at the evidences and supporting the report.

	Members can also go directly to the troll account and report in huge numbers, so as to create a mass reporting effect which will gain the attention of the respective social media team handling such reports.

	If the respective social media report team requires evidences or monitoring or further activies, it can make use of our public support as well as the post created on our platform.

	Each post getting more support of moderators will get a higher level of seriousness via gathering much more community attention and will be considered as a severe abuse.

	If the report created on our platform is found vague or insignificant after verification through verification by moderators or member feedbacks, the post will be taken off. In some cases, action will be taken against the member too.

	each post will carry a list of supporting members' usernames which is only visible to the reporting member, the mods and the admin only.

	No other member with less authority will be provided the username, but only a total count of supporters.

	On deleting a report/post, it will no longer be visible to any other member except for the admin or mods.





	FUTURE PLANS AND SCOPE

		integrating with more social media platforms which will provide us with direct authorities to monitor trolling activities as a 3rd party entrusted application/service.

		using automation through machine knowledge to verify the integrity of reports without human interaction.

		a reputation of each moderator will decide and shuffle the powers based on their performances which will reflect their rep.

		automating the report procedure without individual efforts for visiting and reporting the troll.

		finding and controlling mass observation in any sector of social media and controlling.

		providing assistance to mentally affected mass trolled victims.

		working with celebrities on a professional level who regularly face such scenario.



+