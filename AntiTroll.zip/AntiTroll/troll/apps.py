from django.apps import AppConfig


class TrollConfig(AppConfig):
    name = 'troll'
