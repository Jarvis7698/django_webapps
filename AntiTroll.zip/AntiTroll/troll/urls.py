
from django.urls import path
from . import views
from .views import PostListView, PostDetailView, PostCreateView

urlpatterns = [
    path('', PostListView.as_view(), name='home'),
    path('about/', views.about, name='about'),
    path('post_detail/<int:pk>/', PostDetailView.as_view(), name='post-detail'),
    path('delete/<int:pk>/', views.delete, name='post-delete'),
    path('post/new/', PostCreateView.as_view(), name='post-create'),
    path('support/', views.support, name='support'),
]