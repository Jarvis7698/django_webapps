'''
TROLLN'T : Anti-Trolling Support Community Web Application (Django 3.0.3)
Authors: 
        Kunal Acharya (ig:@jarvis.7698, tw:@jarvis7698)
        Sagar Adulkar (ig:@shaggyy11, tw:@SagarAD12)
        Sagar Vyas (ig:@sagarpvyas.97)
Institute:
        Watumull Institute of Electronics Engineering and Computer Technology
'''

from django.shortcuts import render, redirect, get_object_or_404
from .models import Post
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView, CreateView
from django.contrib import messages

# Create your views here.

def home(request):
	posts = Post.objects.all()
	context = {
		'posts': posts,
	}
	return render(request, 'troll/index.html', context)


def about(request) :
	return render(request, 'troll/about.html')


def delete(request, pk) :
	post = Post.objects.get(id=pk)
	post.hidden = True
	post.save()
	
	return redirect('home')

class PostListView(ListView):
	model = Post
	template_name = 'troll/index.html'
	context_object_name = 'posts'
	ordering = ['-date']


class PostDetailView(DetailView) :
	model = Post


class PostCreateView(LoginRequiredMixin, CreateView) : 
	model = Post
	fields = ['title', 'details', 'snapshot', 'op_link', 'troll_account_link']

	def form_valid(self, form):
		form.instance.author = self.request.user
		return super().form_valid(form)


def support(request) :
	post = get_object_or_404(Post, id=request.POST.get('post_id'))

	if not post.support.filter(id=request.user.id).exists() :
		if request.user.profile.mod :
			post.mod_sup += 1
			post.save()
		post.support.add(request.user)
		messages.success(request, f"Thank you for taking a stand for { post.author.username }'s report! We appreciate your support.")
	else:
		messages.info(request, f'You have already provided support for report "{ post.title }"!')

	return redirect('home')
	#return redirect(post.get_absolute_url())