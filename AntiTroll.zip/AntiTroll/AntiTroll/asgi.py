'''
TROLLN'T : Anti-Trolling Support Community Web Application (Django 3.0.3)
Authors: 
        Kunal Acharya (ig:@jarvis.7698, tw:@jarvis7698)
        Sagar Adulkar (ig:@shaggyy11, tw:@SagarAD12)
        Sagar Vyas (ig:@sagarpvyas.97)
Institute:
        Watumull Institute of Electronics Engineering and Computer Technology
'''

"""
ASGI config for AntiTroll project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.0/howto/deployment/asgi/
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'AntiTroll.settings')

application = get_asgi_application()
