'''
TROLLN'T : Anti-Trolling Support Community Web Application (Django 3.0.3)
Authors: 
        Kunal Acharya (ig:@jarvis.7698, tw:@jarvis7698)
        Sagar Adulkar (ig:@shaggyy11, tw:@SagarAD12)
        Sagar Vyas (ig:@sagarpvyas.97)
Institute:
        Watumull Institute of Electronics Engineering and Computer Technology
'''

"""
WSGI config for AntiTroll project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.0/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'AntiTroll.settings')

application = get_wsgi_application()
